# Frontend Mentor - Rock, Paper, Scissors

![Design preview for the Rock, Paper, Scissors coding challenge](./design/desktop-preview.jpg)

# Installation

`npm install`

# Run the project
`npm run start`
